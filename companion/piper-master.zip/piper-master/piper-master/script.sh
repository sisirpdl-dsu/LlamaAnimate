ollama serve&
ollama run llama3.3
